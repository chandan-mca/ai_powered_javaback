package com.substring.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaConceptsApplicationTests {

	@Test
	void contextLoads() {
	}

}
